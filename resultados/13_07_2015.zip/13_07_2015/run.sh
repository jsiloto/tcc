cd 1
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../2
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../3
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../4
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../5
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../6
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../7
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../8
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../9
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../10
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../11
./GA_PARAM_TEST run > resultado.txt
echo "done"

cd ../12
./GA_PARAM_TEST run > resultado.txt
echo "done"